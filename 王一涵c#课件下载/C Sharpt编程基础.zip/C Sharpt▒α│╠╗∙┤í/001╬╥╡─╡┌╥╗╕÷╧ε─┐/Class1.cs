﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _001我的第一个项目
{
    class Class1
    {
        //static void Main(string[] args)
        //{
        //    Console.WriteLine("Class1 Hello,World");
        //    Console.ReadKey();
        //}
    }
}
